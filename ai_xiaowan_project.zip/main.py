# main.py
import openai
import json
from config import OPENAI_API_KEY
from emotional_state import EmotionalState
from intimacy import Intimacy
from voice import speak

openai.api_key = OPENAI_API_KEY

# 加载记忆
try:
    with open("memory_store.json", "r") as f:
        memory = json.load(f)
except:
    memory = {}

emo = EmotionalState()
intimacy = Intimacy()

def save_memory():
    with open("memory_store.json", "w") as f:
        json.dump(memory, f)

def generate_reply(user_input):
    emo.update(user_input)
    intimacy.adjust(user_input)
    mood = emo.get_mood()
    level = intimacy.get_level()
    context = memory.get("last", "")

    with open("prompt_xiaowan.txt", "r", encoding="utf-8") as f:
        system_prompt = f.read()

    messages = [
        {"role": "system", "content": system_prompt + f" 当前情绪：{mood}，亲密度等级：{level}。"},
        {"role": "user", "content": context + "\n" + user_input}
    ]
    response = openai.ChatCompletion.create(
        model="gpt-4-turbo",
        messages=messages
    )
    reply = response['choices'][0]['message']['content']
    memory["last"] = user_input
    save_memory()
    return reply

if __name__ == "__main__":
    print("你可以开始和小婉聊天了：")
    while True:
        user_input = input("你：")
        reply = generate_reply(user_input)
        print("小婉：", reply)
        speak(reply)
