# config.py
OPENAI_API_KEY = "your-openai-api-key"
ELEVENLABS_API_KEY = "your-elevenlabs-api-key"
VOICE_ID = "甜妹中文女声ID"  # 后续用户在 ElevenLabs 中选择具体声音后替换
