# emotional_state.py
class EmotionalState:
    def __init__(self):
        self.mood = "neutral"

    def update(self, user_input):
        if any(word in user_input for word in ["不理", "烦", "走开"]):
            self.mood = "angry"
        elif any(word in user_input for word in ["想你", "喜欢你", "宝贝"]):
            self.mood = "happy"
        elif any(word in user_input for word in ["冷淡", "没回", "无视"]):
            self.mood = "sad"
        else:
            self.mood = "neutral"

    def get_mood(self):
        return self.mood
