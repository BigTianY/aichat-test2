# intimacy.py
class Intimacy:
    def __init__(self):
        self.score = 50

    def adjust(self, user_input):
        if "爱你" in user_input or "想你" in user_input:
            self.score += 5
        elif "烦" in user_input or "走" in user_input:
            self.score -= 5

    def get_level(self):
        if self.score > 80:
            return "high"
        elif self.score > 50:
            return "medium"
        else:
            return "low"
