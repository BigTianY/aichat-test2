# voice.py
import requests
from config import ELEVENLABS_API_KEY, VOICE_ID

def speak(text):
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{VOICE_ID}"
    headers = {
        "xi-api-key": ELEVENLABS_API_KEY,
        "Content-Type": "application/json"
    }
    data = {
        "text": text,
        "model_id": "eleven_multilingual_v2",
        "voice_settings": {"stability": 0.4, "similarity_boost": 0.75}
    }
    response = requests.post(url, json=data, headers=headers)
    with open("xiaowan_reply.mp3", "wb") as f:
        f.write(response.content)
